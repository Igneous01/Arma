// test macro define
// uncomment next line to enable debugging and logging
#define IGN_LIB_DEBUG